x =9**81 +27**729 - 4
res = ''
while(x> 0):
    res = str(x%9) + res
    x = x//9
res =res.replace('0', '8')
print(res.count('8'))
