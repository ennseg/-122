F1 = 1
F2 = 1
B = 0
print(B)
print(F1)
for i in range(10000000):
    B = F1 + F2
    F1 = F2
    F2 = B
    print(B)
    
    
