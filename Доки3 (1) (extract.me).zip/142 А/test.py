a=7
print(div(4,1))
