a = int(input())
b = int(input())
c = int(input())
ax = str(a)
s = 0
w = 0

for i in range(len(ax)):
    t = (( a // (10 ** i)) % 10 )
    s = s + t * (b ** (i))
    print(t, s)


while s > c:
    i = 1
    w += (s // i) % c
    s = s / c
    i += 1
    print(str(w), end='')
