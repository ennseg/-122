x=int(input("Enter first number"))
print(x)
y=int(input("Enter second number"))
print(y)
z=x**y
print(z)
