Mdc=0
alp="ABCDEFGHIJKLMOPQRSTUVWXYZ"
with open("24-164.txt","r") as F:
    for line in F:
        dc=1
        el = ""
        for i in range(len(line)-1):
            if line[i]==line[i+1]:
                dc+=1
                el=line[i]
                continue
            if line[i]!=line[i+1]:
                if Mdc<dc:
                    Mdc =dc
                    Mel=el
                    KBCH=0
                    BCH=""
                    for let in alp:
                        a=line.count(let)
                        if a>KBCH:
                            KBCH=a
                            BCH=let
                dc =1
f=open("24-164.txt","r")
itog=0
for line in f:
    itog+=line.count(BCH)
print(itog)
        
