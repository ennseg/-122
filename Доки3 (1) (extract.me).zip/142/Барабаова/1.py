a="A, B, W, G, D, E, V, Z, I, K. L, M, N, O, P, R, S, T, U, F, H, C, Q, X"
abc=a.split(", ")
print (abc)
b= ".- -... .-- --. -.. . ...- --.. .. .--- -.- .-.. -- - --- .--. .-. ... - ..- ..-. .... -.-. --.- -..-"
abcm=b.split()
print (abcm)
text=input("введите текст для перевода ")
#for i in range(len (a)):
ind=abc.index ("1")
ind.m=("")
print (ind)
