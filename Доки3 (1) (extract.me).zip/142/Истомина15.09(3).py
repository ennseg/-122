F1 = int(1)
F2 = int(2)
F3 = int()
print ("числа Фибоначи :")
while (F2 +F1) < 100000:
    F3 = F1 + F2
    F1 = F2
    F2 = F3
    print (F3)

    
