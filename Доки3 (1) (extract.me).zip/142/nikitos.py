n10 = int(input('chislo'))
p = int(input('osnovanie'))
k = 1
np =0
while(n10  != 0):
    np += (n10 % p) * k
    k *= 10
    n10 = n10 // p
print('N', p ,  '=', np)

