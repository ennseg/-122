#include <iostream>
#include <fstream>

using namespace std;

int main(){
	int o_ch=0,o_nch=0,kol=0, nc=0,ch=0;
	int N,i,x;
	ifstream F("27-35b.txt");
	F>>N;
	for (i=0; i<N; i++){
		F>>x;
		if (x!=0){
			if (x%2==0){
				ch++;
				kol+=o_ch;
				}
			else{
				nc++;
				kol+=o_nch;
				}
			}
		else{
			o_ch+=ch;
			ch=0;
			o_nch+=nc;
			nc = 0;
			}
		}
	cout<<kol;
	return 0;
	
	}
