'''
x=7**103+20*7**204-3*7**57+97
a='0123456789'
b=''
while x>0:
    b=(a[x%7])+b
    x=x//7
print(b.count('6'))

x=5*216**1256-5*36**1146+4*6**1053-1087
a='0123456789'
b=0
while x>0:
    b+=int(a[x%6])
    x=x//6
print(b)

x=49**129+7**131-2
a='0123456789'
b=''
s=0
while x>0:
    b=(a[x%7])+b
    x=x//7
s=b.count('0')+b.count(max(b))
print(s)

x=13*625**1320+12*125**1230-14*25**1140-13*5**1050-2500
s=0
A="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
while x>0:
    if A[x%25]=='0':
        s+=1
    x=x//25
print(s)
'''
from itertools import*
k=0
for x in product('ВУАЛЬ',repeat=5):
    s=''.join(x)
    if 'ЬУ' not in s and 'ЬА' not in s and s[0]!='Ь':
        if s.count('В')==1 and s.count('У')==1 and s.count('А')==1 and s.count('Л')==1 and s.count('Ь')==1:
            k+=1
           

print(k)
    

















