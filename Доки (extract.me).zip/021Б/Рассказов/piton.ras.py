a=int(input('введите 1-е число '))
b=int(input('введите 2-е число '))
c=(a+b)
print(c**b)
