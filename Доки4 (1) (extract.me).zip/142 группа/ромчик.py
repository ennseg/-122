x=int(input("введи основу"))
print(x)
y=int(input("введи основу"))
z=int()
for i in range(1, y)
z=z+x*x
print(z)

