#include <iostream>
#include <fstream>

using namespace std;

int main(){
	int N,i,result = 0,x,a;
	int numbers[10001];
	for(i=0;i<sizeof(numbers)/sizeof(int); i++) numbers[i]=0;
	ifstream F("27-37b.txt");
	F>>N;
	for (i=0; i<N;i++){
		F>>x;
		a=1;
		while (a<=x-a){
			if (a<x-a) result +=numbers[a]*numbers[x-a];
			else result+=numbers[a]*(numbers[a]-1)/2;
			a+=1;
			}
		numbers[x]+=1;
		}
	cout<<result;
	return 0;
	
	}
