x=int(input("vvedi chislo"))
y=int(input("vvedi chislo"))
itogo=int(1)

for i in range(y):
    itogo=itogo*x
print(f"itog {itogo}")

    

