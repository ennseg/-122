#include <iostream>
#include <fstream>

using namespace std;

int main(){
	int i,m,N,tmax,M,tmin,num;
	ifstream F("27-19b.txt");
	F>>N;
	F>>num;
	tmax=M=tmin=num;
	for (i=0; i<N-1;i++){
		F>>num;
		m=min(num,min(num*tmin,num*tmax));
		tmax = max(num,max(num*tmin,num*tmax));
		tmin = m;
		M = max(M,tmax);
		}
	cout<<M;
	return 0;
	
}
