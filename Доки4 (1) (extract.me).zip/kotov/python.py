x=7*5*1984-6*25**777+5*125**333-4
A="0123456789ABCDEP"
res=""
while (x>0):
   res=A[x%5]+res
   x=x//5
k=0

print(k)
