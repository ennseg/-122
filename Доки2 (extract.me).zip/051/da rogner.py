a = int(input())
b = int(input())
c = str(a)
s = 0

for i in range(len(c)):
    t = (( a // (10 ** i)) % 10 )
    s = s + t * (b ** (i))
    print(t, s)
    
