"""from string import ascii_lowercase, digits

x=3*11**58+15*11**55-99*11**18+125*11**9+381

def gen_digs(n, base=11):
    alphabet = digits+ascii_lowercase
    while n > 0:
        yield alphabet[n % base]
        n = n // base
digs = ''
for i in gen_digs(x):
    if i not in digs:
        digs += i
print(digs)
print(len(digs))"""
"""x = 9**81 + 27**729 - 4
c = 0
while x > 0:
    if x % 9 in [0, 8]:
        c += 1
    x = x // 9
print(c)"""
"""from string import ascii_lowercase, digits
import re
x=81**79 + 75**2022 - 12**35
def tobase(n, base=5):
    alphabet = digits+ascii_lowercase
    res = ''
    while n > 0:
        res = alphabet[n % base] + res
        n = n // base
    return res
print(len(re.findall('4[1-3]', tobase(x))))"""

