x = 53**123 +65**2222 - 172**12
res=''
while(x>0):
    res = str(x%7) + res
    x=x//7
print(res.count("61") + res.count('62')+ res.count('63')+ res.count('64')+res.count("65"))
