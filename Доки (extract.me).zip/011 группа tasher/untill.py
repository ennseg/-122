'''
x=6**333-5*6**215+3*6**144-85
res=0
while (x>0):
    if x%6==5:res+=1
    x=x//6
print(res)
'''
'''
x=4**1503+3*4**244-2*4*1444-96
rea=0
while(x>0):
    
    rea+=x%4
    x=x//4
    
print(rea)
'''
'''
x=53**123+65*2222-172**12
res=""
while(x>0):
        res=str(x%7)+res
        x=x//7
print(res.count("61")+res.count("64")+res.count("63")+res.count("62")+res.count("65"))
'''
x=16**44*16**30-(32**5*(8**40-8**32)*(16**17-32**4))
x16=hex(x)[2:]
x16=x16.replace("f","0")
x16=x16[:-3]
while x//6[0]=="0":
    x16=x16[1:]
print(x16.count('0'))
