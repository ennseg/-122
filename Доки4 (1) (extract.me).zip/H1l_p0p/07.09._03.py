import random as rm

a = [chr(i) for i in range(ord("A"), ord("Z")+1)] + ["_", "."] + [str(i) for i in range(0,10)]

mx = 0
nm = ''

def GetMax(func):
    global mx
    def _wrapper(func):
        global mx
        if func['time']>mx: nm = func[name]
        mx = max(mx, func['time'])
        return mx
    return _wrapper

class User(object):
    global a
    
    def __init__(self):
        global a
        self.date = rm.randint(0,366) #day
        self.name = ''.join([a[rm.randint(0,len(a)-1)] for i in range(10)])
        self.ip = f'{rm.randint(0,256)}.{rm.randint(0,256)}.{rm.randint(0,256)}.{rm.randint(0,256)}'
        self.tp = rm.choice(list('UAG'))
        self.time = rm.randint(0, 800) #hours

    @GetMax
    def getInfo(self):
        return {'date': self.date, 'name':self.name, 'ip':self.ip, 'tp':self.tp, 'time':self.time}


z = []
for i in range(100):
    z.append(User(i))

for i in z:
    print(i.getInfo())

print(mx)
