for x in range(p-1)
for y in range(p-1)
