a=[]
x=23175
a=list(str(x))
a.reverse()
print (a)

