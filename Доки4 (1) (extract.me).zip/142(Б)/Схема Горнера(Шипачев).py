a = int(input("введите число"))
b = int(input("введите систему счисления этого числа"))
x = a
e = 1
O = int()
z = float()
while x > 1:
    e = e + 1
    x = a / (10**e)
for i in range(e):
    if i == 6:
        break
    elif i == 0:
        z = (a % 10)
    else:
        z = (a % 10**(i+1))// 10**(i) * b**i
    print(z)
    O = O + z
print(O)

    
