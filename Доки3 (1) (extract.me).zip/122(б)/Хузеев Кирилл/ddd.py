print ('ddd')
