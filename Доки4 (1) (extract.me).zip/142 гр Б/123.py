a="абвгдеёжзийк"
alf=list(a)
print (alf)
mors=".- -... .-- --. -.. . .... ...- --.. .. .--- -.-"
alfm=mors.split()
print (alfm)
morze=input("текст")
for i in range(len(morze)):
    print (morze[i])
    

