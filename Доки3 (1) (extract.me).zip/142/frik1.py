noun = int(input('Введи число '))
y = int(input('Введи систему счисления '))
a = list(str(noun))
x = len(a)
st = x - 1
itogo = 0
for i in range (x):
    itog = int(a[i])*y**st
    itogo += itog
    st -= 1
print (itogo)
