#print(sum([1 if len(set(i))==1 else 0 for i in input().split()]))
import itertools as it
def To(a, base=10):
    alpha = list('0123456789') + [chr(i) for i in range(ord("A"), ord("Z")+1)]
    res = ''
    while a>0:
        res = alpha[a%base]+res
        a = a// base
    return res
'''
#1
a = 7**103+20*7**204-3*7**57+97
print(f'1 - {To(a, 7).count("6")}')
#2
a = 5*216**1256-5*36**1146+4*6**1053-1087
print(f'2 - {sum(list(map(int, list(To(a, 6)))))}')
#3
a = 49**129+7**131-2
z = To(a,7)
print(f'3 - {z.count("0")+z.count(str(max(list(z))))}')
#4
a = 13*625**1320+12*125**1230-14*25**1140-13*5**1050-2500
print(f'4 - {To(a, 25).count("0")}')
'''
#5
'''
import itertools as it
res = 0
for i in it.product('ABO', repeat=5):
    if i[0] in 'AO':
        res+=1
print(res)
'''
#6
'''res = 0
for i in it.product('ACGT', repeat=5):
    if ''.join(i).count('A')==2:
        res+=1
print(res)
'''
#7
'''
res = 0
a=['AD', 'DA']
for i in it.product('ABCD', repeat=3):
    j= ''.join(i)
    if 'BC' in j or 'CB' in j: continue
    if j.count('A')<=2 and 'AA' in j: continue
    else:
        if 'AD' in j or 'DA' in j or j.count('A')==0:
            res+=1
print(res)
'''
#8
'''
st = []
for i in it.permutations('KANKAN', 6):
    j = ''.join(i)
    if 'KK' in j and "NN" in j and 'AA' in j: continue
    else: st.append(j)
print(len(set(st)))
'''
#9
'''
res = 0
for i in it.permutations('ВУАЛЬ', r=5):
    if i[0]=='Ь': continue
    if 'ЬА' in ''.join(i) or 'ЬУ' in ''.join(i): continue
    res+=1
print(res)
'''
#10
res = 0
for i in it.product('0123456789', repeat=5):
    if int(''.join(i))%5!=0: continue
    z = list(map(int, i))
    for j in :
