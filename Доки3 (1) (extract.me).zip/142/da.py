with open("wtf_moment.txt", mode="r+") as wtf_moment:
    sum = 0
    for i in range(10):
        sum += int(wtf_moment.readline())
    wtf_moment.write(f"\n\n\n{sum}")
    
