#include <iostream>
#include <fstream>

using namespace std;

int main(){
	int kol=0,k7=0,k2=0,k14=0,k=0,x,N;
	int buf[7];
	ifstream F("27-13a.txt");
	F>>N;
	for (int i=0;i<7;i++) F>>buf[i];
	
	for (int i=7;i<N; i++){
		if (buf[0]%2==0 and buf[0]%7!=0) k2+=1;
        else {
			if (buf[0]%2!=0 and buf[0]%7==0) k7+=1;
			else{
				if (buf[0]%14==0 ) k14+=1;
				else  k+=1;
				}
			}
		F>>x;
        if (x%2==0 and x%7!=0) kol+=k14+k7;
         else { 
			if (x%2!=0 and x%7==0) kol+=k14+k2;
			else {
				if (x%14==0 ) kol+=k14+k2+k7+k;
				else kol+=k14;
				}
			}
        for (int j=0;j<6; j++) buf[j] = buf[j+1];
        buf[6]=x;
		
		}
	cout<<kol;
	return 0;
}
