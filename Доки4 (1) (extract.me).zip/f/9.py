x = 0
a = int(str(3364) + str(x))
b = int(str(x)+ str(7946))
c = int(str(55) + str(x) + str(87))
def deca(n, k):
    res = 0
    arr = list(str(n))[::-1]
    i = 0
    while(i< len(arr)):
        res+= int(arr[i]) *k**i
        i+=1
    return(int(res))
print(deca(a,11))
while(x<10):
    a = int(str(3364) + str(x))
    b = int(str(x)+ str(7946))
    c = int(str(55) + str(x) + str(87))
    if(deca(a,11) +deca(b,12) ==deca(c,14)):
        print(x)
        print(deca(c,14))
    x+=1
    print(c)
