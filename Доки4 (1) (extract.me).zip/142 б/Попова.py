x=int(inpyt("ведите основу"))
print(x)
