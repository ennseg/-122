x = 7*5**1984 - 6*25**777 + 5*125**333-4
res = ''
arr = []
while(x > 0):
    res = str(x%5) + res
    arr.append(x%5)
    x = x//5
print(sum(arr))
