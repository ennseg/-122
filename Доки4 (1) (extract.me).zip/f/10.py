'''
x =1073741825
c=0
while(x<(4294967299)):
    if(len(hex(x)) <= 10):
        if(len(oct(x)) >=13):
            c+=1
            #print(c)
    x+=10
    
print(c)
'''
k=0
for i in range(int('10000000000',8),int('FFFFFFFF',16),10):
    k+=1
print(k)
