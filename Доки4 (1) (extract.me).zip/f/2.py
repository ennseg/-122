x= 4**1503+3*4**244 - 2*4**1444-96
arr=[]
while(x>0):
    arr.append(x%4)
    x=x//4
print(sum(arr))
