#include <iostream>
#include <fstream>

using namespace std;

int rev(int n){
		return (n%10*100+n/10%10*10+n/100);
	}
bool pol(int n){
	return (n==rev(n))? true:false;
	}
int s_dig(int n){
	return (n%10+n/10%10+n/100);
	}
int main(){
	int x,max_n=0,result=0,i,N;
	int mas[1000];
	for (i=0;i<1000;i++) mas[i]=0;
	ifstream F("27-39b.txt");
	F>>N;
	
	for ( i=0; i<N; i++) {
		F>>x;
		mas[x]++;
		}
	for (i=100;i<1000;i++){
		if((!pol(i)) and mas[i]!=0){
			result+=min(mas[i],mas[rev(i)])*2*s_dig(i);
			mas[rev(i)]=0;
			}
		else{
			if (pol(i) and mas[i]!=0){
				if (mas[i]%2==0) result+=mas[i]*s_dig(i);
				else{
					result+=(mas[i]-1)*s_dig(i);
					if (i>max_n) max_n = i;
					}
				}
			}
		}
	cout<<result+s_dig(max_n);
	return 0;
	}
