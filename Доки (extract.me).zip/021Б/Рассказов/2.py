a=[3, 7, 9]
a.reverse()
print(a)
