with open("27-8a.txt","r") as F:
    min_s = 100000000
    min_buf0 = 1000000
    N = int(F.readline())
    buf = [0]*5
    for i in range(5):
        buf[i] = int(F.readline())
    for line in F:
        min_buf0 = min(min_buf0,buf[0])
        min_s = min(min_s, min_buf0**2+int(line)**2)

        for i in range(4):
            buf[i] = buf[i+1]
        buf[4] = int(line)
print(min_s)