'''def f(start,stop):
    if start>stop:
        return 0
    if start==stop:
        return 1
    if start<stop:
        return f(start+3,stop)+f((start*2)+1,stop)
k=0
for i in range(1,1000):
    if f(2,i)>0:
        k+=1
print(k)'''



'''def f(x,y,s):
    if x+y>=62 and (s==4 or s==2):
        return True
    if x+y>=62 and s<4:
        return False
    
    if x+y<62 and s==4:
        return False
    if x+y<62 and s<4:
        if (s%2==0):
            return f(x+1,y,s+1) and f(x,y+1,s+1) and f(x+y,y,s+1) and f(x,y+x,s+1)
        else:
            return f(x+1,y,s+1) or f(x,y+1,s+1) or f(x+y,y,s+1) or f(x,y+x,s+1)
for i in range(1,54):
    if f(8,i,0):
        print(i)'''


'''def f(x,s):
    if x>=65 and x<=100 and s==4:
        return True
    if x>100 and (s==3 or s==1):
        return True
    if x>100 and s==4:
        return False
    if x<65 and s==4:
        return False
    if x>=65 and x<=100 and s<4:
        return False
    if x<65 and s<4:
        if  s%2==0:
            return f(x+1,s+1) and f(x*3,s+1)
        else:
            return f(x+1,s+1) or f(x*3,s+1)
for i in range(1,65):
    if f(i,0):
        print(i)'''






        
