#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

int main(){
	int minr1=10000,minr2=10000,minr3=10000;
	int s1=0,s2=0,s3=0,N;
	int mas[3];
	ifstream F("27-41a.txt");
	F>>N;
	for (int i=0; i<N; i++){
		F>>mas[0]>>mas[1]>>mas[2];
		sort(mas,mas+3,greater<int>());//сортировка массива по убыванию
		s1+=mas[0];
		s2+=mas[1];
		s3+=mas[2];
		if ((mas[0]-mas[1])%2!=0) minr1 = min(minr1,mas[0]-mas[1]);
        if ((mas[0]-mas[2])%2!=0) minr2 = min(minr2,mas[0]-mas[2]);
        if ((mas[1]-mas[2])%2!=0) minr3 = min(minr3,mas[1]-mas[2]);
		}
	if (s1%2!=s2%2) cout<<s3;
	else cout<<s3+min(minr2,minr3);
	return 0;
}
