a = int(input())
b = int(input())
c = 1
for _ in range(b):
    c *= a
print(c)
