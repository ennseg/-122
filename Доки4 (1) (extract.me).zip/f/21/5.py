#from itertools import *
import itertools
k = 0
g = []
for x in itertools.permutations('0123456789', 5):
    i=0
    f =true
    s="".join(x)
    if(len(s)== len(set(s))):
        while(i<len(s)-1):
            if((s[i]%2 ==0 and s[i+1])or(s[i+1] ))
print(k)
