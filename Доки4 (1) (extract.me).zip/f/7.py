x = 81 ** 79 +75** 2022 -12**35
res = ''
while(x > 0):
    res = str(x%5) + res
    x = x//5
print(res.count('41') + res.count('42') + res.count('43'))
