import sqlite3 as sl
con = sl.connect('yyy.db')
sql = 'INSERT INTO USER (id, name, age) values(?, ?, ?)'
data = [
    (12, 'Саша', 21),
    (11, 'Паша', 22),
    (10, 'Лёня', 23)
]
with con:
    con.executemany(sql, data)
with con:
    data = con.execute("SELECT * FROM USER WHERE age <= 22")
    for row in data:
        print(row)
