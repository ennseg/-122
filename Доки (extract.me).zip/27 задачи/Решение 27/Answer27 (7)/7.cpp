#include <iostream>
#include <fstream>

using namespace std;

int main(){
	int result[9] = {0,0,0,0,0,0,0,0,0};
	ifstream F("27-31b.txt");
	int N,s,i,j,k,x,y,z;
	int sums[3];
	int c_sum[9];
	F>>N;
	for (i=0;i<N; i++){
		F>>x>>y>>z;
		for (j=0; j<9; j++) c_sum[j] = 100000000;
		sums[0] = x+y;
		sums[1] = x+z;
		sums[2] = z+y;
		for (j=0; j<9; j++){
			for (k=0;k<3;k++){
				s=result[j]+sums[k];
				c_sum[s%9] = min(s,c_sum[s%9]);
				}
			}
		for (j=0; j<9; j++) result[j]=c_sum[j];
		
		}
	int minim = 100000000;
	for (j=1; j<9; j++) minim = min(minim,result[j]);
	cout<<minim;
	return 0;
}
