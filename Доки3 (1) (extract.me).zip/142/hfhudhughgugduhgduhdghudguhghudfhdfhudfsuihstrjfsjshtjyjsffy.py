N10 = int(input("Введите 10-чное число: "))
p = int(input("Ввдеите основание систмы: "))

k = 1
Np = 0
while N10 != 0:
    Np += (N10 % p) * k

    k *= 10
    N10 = N10 // p

print(Np)
        
