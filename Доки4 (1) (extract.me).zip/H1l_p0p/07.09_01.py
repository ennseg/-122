import random as rn
name = "first"
path = name+".txt"

f = open(path, 'w')
sm = 0
a = []
for i in range(20):
    a.append(rn.randint(0,100)/10)
    now = a[len(a)-1]
    if now - int(now) >0:
        sm += now - int(now)


print("\n".join(list(map(str, a))) + "\nsum = "+str(sm), file=f)
f.close()
