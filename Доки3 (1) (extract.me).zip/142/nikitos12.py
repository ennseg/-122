x = int(1)
y = int(2)
while(x + y < 2000):
    x3=x+y
    print(x3)
    x=y
    y=x3
    
    
    
