x=int(input("Введите основу"))
y=int(input("степень"))
summ = int()
for i in range(1,y):
    summ = summ+x*x
print(summ)

        

        
        

        
        
