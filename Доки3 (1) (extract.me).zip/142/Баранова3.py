x=1
y=1
n=input("введите число")
n=int(n)
p=2
while p < y:
    N=x+y
    x=y
    y=N
    p+=1

print(N)
