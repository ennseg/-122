x = 6**333 - 5*6**215 +3*6**144-85
res = 0
print(x)
while(x>0):
    if(x%6==5):
        res+=1
    x=x//6
print(res)
