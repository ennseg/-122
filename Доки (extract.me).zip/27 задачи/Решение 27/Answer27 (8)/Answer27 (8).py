minr1 = minr2 = minr3 =1000000
s1,s2,s3=0,0,0
with open("27-41a.txt","r") as F:
    N = int(F.readline())
    for line in F:
        mas = sorted([int(x) for x in line.split() ],reverse = True)
        s1+=mas[0]
        s2+=mas[1]
        s3+=mas[2]
        if (mas[0]-mas[1])%2!=0: minr1 = min(minr1,mas[0]-mas[1])
        if (mas[0]-mas[2])%2!=0: minr2 = min(minr2,mas[0]-mas[2])
        if (mas[1]-mas[2])%2!=0: minr3 = min(minr3,mas[1]-mas[2])
if s1%2!=s2%2:
    print(s3)
else:
    print(s3+min(minr2,minr3))