a = str('A B W G D E V Z I J K L M N O P R S T U F H C Q X')
abc = list(a)
print (a)
m = str('.- -... .-- --. -.. . ...- --.. .. .--- -.- .-.. -- - --- .--. .-. ... - ..- ..-. .... -.-. ---.  - ..- ..-. .... -.-. --.- -..-')
morze = list(m)
print morze.split(''))
text = input()
ind_m = ''
for i in range (len(text_list)):
    ind = abc.index(text[i])
    ind_m = ind_m + norze[ind]
print (indm)
    
    
    
    
    
