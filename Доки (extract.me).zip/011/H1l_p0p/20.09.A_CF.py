import math
import itertools as it
a = input()
print(len(list(it.combinations(a,len(a)))))
print(list(it.combinations(a,len(a))))

