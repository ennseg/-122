a = int (input () )
b=int (input () )
с= 1
for _ in range(b) :
     с *= a
print(c)

