d=0
mdp=0
f=open("24-173.txt")
s = f.readline()
for i in range(len(s)-5):
      t1 = s[i]+s[i+1]+s[i+2]
      t2= s[i+3]+s[i+4]+s[i+5]
      if t1!=t2:
            d+=1
      else:
            d+=5
            mdp=max(mdp,d)
            d=0
print(mdp)
