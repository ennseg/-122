mdp=""
s=""
with open("24-171.txt") as F:
    for line in F:
        i=0
        while (i<len(line)-2):
            if line[i]+line[i+1]+line[i+2]=="XYZ":
                s+=line[i]+line[i+1]+line[i+2]
                i+=3
            else:
                i+=1
                if len(mdp)<len(s):
                    mdp=s
                s=""
print(mdp)
