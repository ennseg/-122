a=int(input(f"введите основание степени"))
print(f"a = {a}")
n=int(input(f"введите показатель степени"))
print(f"n = {n}")
b=a
while(n>1):
    b=b*a
    n=n-1
print(f"а^n = {b}")
