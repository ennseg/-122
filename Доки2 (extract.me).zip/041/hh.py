import sqlite3 as sl
con = sl.connect('петры.db')
with con:
    con.execute("""
CREATE TABLE USER (
    id INTEGER,
    name VARCHAR,
    last name VARCHAR
    year DATE,
    PRIMARY KEY (id));
""")
sql = 'INSERT INTO петры.db (id, name, last name, year)' 
data = [(1, 'Петр', 'Первый', 1672),
        (2, 'Петр', 'Второй', 1715),
        (1, 'Петр', 'Третий', 1728)]

with con:
    data = con.execute("SELECT * FROM петры.db WHERE year < 1725")
    for row in data:
        print(row)
