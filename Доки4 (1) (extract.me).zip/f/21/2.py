x= 5*216**1256 - 5*36**1146+ 4*6**1053-1087
res= ''
while(x>0):
    res =str(x%6) + res
    x=x//6
i = 0
c=0
while(i<len(res)):
    c+= int(res[i])
    i+=1
print(c)
