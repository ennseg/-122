n10=int(input("введите 10-ично число"))
p=int(input("введите основание системы"))
k=int(1)
np=int(0)
while n10!=0:
    np=np+(n10 (n10%p)*k
    k = k*10
    n10=n10//p

print (f"n{p}= {np}")


            
