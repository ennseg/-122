def To(n, base = 10):
    alpha = list('0123456789') + [chr(i) for i in range(ord('A'), ord('Z')+1)]
    if base>len(alpha):
        raise Error("")
    res  = ''
    while n>0:
        res+=alpha[n%base]
        n = n//base
    return res[::-1]

#12
print('12 - ', end='')
print(str(To(6**333-5*6**215+3*6**144-85, 6)).count('5'))
#11
print('11 - ', end='')
print(sum(list(map(int, list(To(4**1503+3*4**244-2*4**1444-96, 4))))))
#10
print('10 - ', end ='')
n = To(53**123+65**2222-172**12,7)
print(sum([1 if n[i:i+2] in ['6'+str(j) for j in range(1,6)] else 0 for i in range(len(n)-1)]))
#9
print('9 - ', end='')
n = To((16**74)-((32**5)*(8**40-8**32)*(16**17-32**4)), 16).replace("F", "0")[:-3]
while n[0]=="0": n = n[1:]
print(n.count('0'))
#8
print('8 - ', end='')
print(len(set(To(3*11**58+15*11**55-99*11**18+125*11**9+381, 11))))
#7
print('7 - ', end='')
n = To(9**81+27**729-4,9)
print(n.count('0') + n.count(max(set(n))))
#6
print('6 - ', end='')
n = To(81**79+75**2022-12**35, 5)
print(sum(([1 if n[i:i+2] in ["41", "42", "43"] else 0 for i in range(len(n)-1)])))
#5
print('5 - ', end='')
print(sum([int(i) for i in To(7*5**1984-6*25**777+5*125**33-4,5)]))
