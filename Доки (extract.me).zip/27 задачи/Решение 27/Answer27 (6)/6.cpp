#include <iostream>
#include <fstream>

using namespace std;

int nod(int x, int y){
	while (x!=y){
		if (x>y) x-=y; else y-=x;
		}
	return x;
	}

int main(){
	int result[10] = {0,0,0,0,0,0,0,0,0,0};
	ifstream F("27-36a.txt");
	int N,s,i,j,k,x,y,z;
	int nods[3];
	int c_sum[10];
	F>>N;
	for (i=0;i<N; i++){
		F>>x>>y>>z;
		for (j=0; j<10; j++) c_sum[j] = 0;
		nods[0] = nod(x,y);
		nods[1] = nod(x,z);
		nods[2] = nod(z,y);
		for (j=0; j<10; j++){
			for (k=0;k<3;k++){
				s=result[j]+nods[k];
				c_sum[s%10] = max(s,c_sum[s%10]);
				}
			}
		for (j=0; j<10; j++) result[j]=c_sum[j];
		
		}
	cout<<result[0];
	return 0;
}
