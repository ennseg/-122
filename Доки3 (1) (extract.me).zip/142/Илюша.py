a="abwgdevzijklmnoprstufhcqx"
abc=list(a)
print(abc)
b=".- -... .-- --. -.. . ...- --.. .. .--- -.- .-.. -- - --- .--. .-. ... - ..- ..-. .... -.-. --.- -..-"
abcm=b.split()
print(abcm)
text=input(f"Введите текст на английским языке >>> ")
indm=""
for i in range(len(text)):
    ind=abc.index(text[i])
    indm=ind+abcm[ind]
print(indm)
