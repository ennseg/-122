fib1 = 0
fib2 = 1
fib_sum=0
i=0
while fib_sum<1000:
    fib_sum=fib1+fib2
    fib_sum2=fib_sum-fib1
    fib1=fib2
    fib2=fib_sum
    i=i+1
    print(fib_sum2)
