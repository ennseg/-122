'''def pr(n):
    if n%2==0:return False
    for i in range(2,int(n**0.5)+1):
        if n%i==0: return False
    return True
for j in range(3,94):
    if pr(j):
        for l in range(26):
            s=(2**l)*(j**4)
            if 63000000<=s<=75000000:
                print(s,j**4)'''
'''def pr(n):
    for i in range(2,int(n**0.5)+1):
        if n%i==0: return False
    return True
a=[]
for j in range(298435,363250):
    k=0
    for l in range(2,int(j**0.5)+1):
        if j%l==0:
            if pr(l) and pr(j//l) and j//l!=l:
                a.append(j)
            else:k+=1
        if k==1:
            break
print(len(a))
s=(sum(a)/len(a))
k=400000
kl=0
for i in a:
    if abs(s-i)<k:
        k=abs(s-i)
        kl=i
print(kl)'''
'''def pr(n):
    for i in range(2,int(n**0.5)+1):
        if n%i==0: return False
    return True
a=[]
for j in range(158928,345294):
    k=0
    for l in range(2,int(j**0.5)+1):
        if j%l==0:
            if pr(l):
                s=j//l
                for m in range(l+1,int(s**0.5)+1):
                    if s%m==0:
                        if pr(m) and pr(s//m) and s//m!=m:
                            a.append(j)
                            k+=1
            else:k+=1
        if k==1:
            break
print(len(a),min(a))'''
#417283
#1070
'''a=[]
for i in range(2,1070):
    b=[]
    for j in range'''
def pr(n):
    b=[]
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            b.append(i)
            if n//i!=i:
                b.append(n//i)
    return(b)
a=[]
c=[]
for j in range(834567,1143211):
    c=pr(j)
    if len(c)>1:
        k=0
        c.sort
        for l in range(len(c)-1):
            if not(c[l+1]-c[l]==2):
                k+=1
        if k==0:
            print(j,max(c))