with open("27-19b.txt","r") as F:
    N = int(F.readline())
    tmax = M = tmin = num = int(F.readline())
    for line in F:
        num = int(line)
        m = min(num,num*tmin,num*tmax)
        tmax = max(num,num*tmin,num*tmax)
        tmin = m
        M = max(M,tmax)
print(M)

