#include <iostream>
#include <fstream>

using namespace std;

int main(){
	int min_s,min_buf0,N,x;
	min_s = 10000000;
	min_buf0 = 10000000;
	int buf[5];
	ifstream F("27-8a.txt");
	F>>N;
	for (int i=0; i<5;i++) F>>buf[i];
	for (int i=5; i<N; i++){
		F>>x;
		min_buf0= min(min_buf0,buf[0]);
		min_s = min(min_s,min_buf0*min_buf0+x*x);
		
		for (int i=0; i<4;i++) buf[i]=buf[i+1];
		buf[4]=x;
		}
	cout<<min_s;
	return 0;
	}
