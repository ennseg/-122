'''x=int(input("Введите первое число"))
y=int(input("Введите второе число"))
z=1
while y>0:
    z=x*x
    y=y-1
print(z)
'''
len=int(input())
osnova=int(input())
