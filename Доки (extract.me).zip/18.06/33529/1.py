res=[0]*2
chet=0
nechet=0
with open('27-B.txt', 'r') as f:
    n=int(f.readline())
    for line in f:
        a=[int(x) for x in line.split()]
        c_res=[0]*2
        for el in res:
            if a[0]%2==0:
                chet+=1
                s=el+a[0]
                if c_res[s%2]<s:
                    c_res[s%2]=s
            else:
                nechet+=1
                s=el+a[0]
                if c_res[s%2]<s:
                    c_res[s%2]=s
            if a[1]%2==0:
                chet+=1
                s=el+a[1]
                if c_res[s%2]<s:
                    c_res[s%2]=s
            else:
                nechet+=1
                s=el+a[1]
                if c_res[s%2]<s:
                    c_res[s%2]=s
            res=c_res[:]
if chet<nechet:
    print(res[0])
else:
    print(res[1])
print(n,chet,nechet)
