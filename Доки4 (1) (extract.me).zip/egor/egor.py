def eight(x):
    if (oct(x).count('6'))>0 and (oct(x).count('7'))==0:
        return True
    else:
        return False

k=0
a=[]
for x in range(777, 19991):
    if eight(int(x)) and (x%11==0 or x%13==0) and x%15!=0 :
        k+=1
        a.append(x)
print(k, max(a)-min(a))
        





               
                


        
