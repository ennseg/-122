x = 3*11**58 + 15 * 11**55 - 99*11**18+125*11**9 + 381
print(x)
res = ''
while(x > 0):
    if(x%11 == 10):
        res = 'a' + res
    else: res = str(x%11) + res
    x= x//11
print(set(res))
