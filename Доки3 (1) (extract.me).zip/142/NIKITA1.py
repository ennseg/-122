p = int(input())
summ=0
for x in range(1, p):
    for y in range(1, p):
        summ  = (x * y // p) * 10 + (x * y)%p
        print(summ, end = ' ')
    print()
        
