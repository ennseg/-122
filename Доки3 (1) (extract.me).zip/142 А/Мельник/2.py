x=int(input("Введите число:"))
y=int(input("Введите степень:"))
z=int(1)
for i in range(y):
    z=z*x
print(f"Итог:{z}")
    
