x=int(input("Введите число:"))
y=int(input("Введите число:"))
for i in range(y):
Z=Z+x*x
print(f"Итог:{Z}")

            
