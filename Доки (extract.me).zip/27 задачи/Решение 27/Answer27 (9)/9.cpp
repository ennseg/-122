#include <iostream>
#include <fstream>

using namespace std;

int main(){
	int result_min[10] = {0,0,0,0,0,0,0,0,0,0};
	int result_max[10] = {0,0,0,0,0,0,0,0,0,0};
	int mas[2];
	ifstream F("27-47b.txt");
	int N,s,i,j,k;
	int c_sum_min[10];
	int c_sum_max[10];
	F>>N;
	for (i=0;i<N;i++){
		F>>mas[0]>>mas[1];
		for (j=0; j<10; j++){
			c_sum_min[j]=1000000000;
			c_sum_max[j]=0;
			}
		for (j=0; j<10; j++)
			for (k=0; k<2; k++){
				s = result_min[j]+mas[k];
				c_sum_min[s%10]=min(c_sum_min[s%10],s);
				
				s = result_max[j]+mas[k];
				c_sum_max[s%10]=max(c_sum_max[s%10],s);
				}
		for (j=0; j<10; j++){
			result_min[j]=c_sum_min[j];
			result_max[j]=c_sum_max[j];
			}
		}
		
	int maxim=0;
	for (j=0; j<10; j++) maxim = max(maxim,result_max[j]);
	cout<<result_min[maxim%10];
	return 0;
}
	
