result = [0]*9
with open("27-31b.txt","r") as F:
    N = int(F.readline())
    for line in F:
        A = [int(x) for x in line.split()]
        nods =[A[0]+A[1],A[0]+A[2],A[1]+A[2]]
        c_sum = [1000000000]*9
        for el in result:
            for n in nods:
                s = el+n
                c_sum[s%9]= min(s,c_sum[s%9])
        result = c_sum[::]
print(min(result[1:]))