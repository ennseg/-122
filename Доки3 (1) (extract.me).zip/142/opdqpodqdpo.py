
print('N10=')
N10=int(input())
print('p=')
p=int(input())
k=int(1)
Np=int(0)
while not N10 == 0:
    Np=Np+(N10%p)*k
    k=k*10
    N10=N10//p
print('N ',p , ' = ', Np)
