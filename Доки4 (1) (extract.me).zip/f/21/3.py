x= 49**129 + 7**131 -2
res= ''
while(x>0):
    res = str(x%7) + res
    x=x//7
res = res.replace('0', '6')
print(res.count('6'))
