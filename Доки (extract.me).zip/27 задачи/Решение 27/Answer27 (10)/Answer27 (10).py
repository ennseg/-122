kol = 0
buf=[]
k7,k2,k14,k=0,0,0,0
with open("27-13a.txt","r") as F:
    N = F.readline()
    for i in range(7):
        buf.append(int(F.readline()))
    for line in F:
        if buf[0]%2==0 and buf[0]%7!=0: k2+=1
        elif buf[0]%2!=0 and buf[0]%7==0: k7+=1
        elif buf[0]%14==0 : k14+=1
        else: k+=1

        if int(line)%2==0 and int(line)%7!=0: kol+=k14+k7
        elif int(line)%2!=0 and int(line)%7==0: kol+=k14+k2
        elif int(line)%14==0 : kol+=k14+k2+k7+k
        else: kol+=k14
        for i in range(6):
            buf[i] = buf[i+1]
        buf[6]=int(line)
print(kol)