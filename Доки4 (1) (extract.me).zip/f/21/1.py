x = 7**103 + 20*7**204 - 3*7**57 + 97

res= ''
while(x>0):
    res = str(x%7) + res
    x=x//7
print(res.count('6'))
