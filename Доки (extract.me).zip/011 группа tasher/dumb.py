'''
F=open('новый файл.txt','r')
A=[]
k=0
for line in F:
    A.append(int(line))
for a in range (len(A)):
    for b in range (len(A)):
        for c in range (len(A)):
            if A[a]<A[b]<A[c]:
             if (A[a]**2)+(A[b]**2)==(A[c]**2):
                        k+=1
print (k)
'''
'''
import random
A=[]
c=0
b=0
F=open('MOZGOTRON.txt','w')
for i in range (5):
    F.write(str(random.uniform(0,100))+'\n')
F.close
F=open('MOZGOTRON.txt','r')
for line in F:
    A.append(float(line))
for i in range (len(A)):
    c+=int(A[i])
    b+=A[i]-int(A[i])
print(c, b)
'''
import random
F=open('MOZGOTRON2.txt','w')
for i in range (20):
    F.write(str(random.randint(0,200))+'\n')
F.close       
