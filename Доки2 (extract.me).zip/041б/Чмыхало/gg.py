i=int(input())
b=int(input())
print(b**i)
