a = input['enter the spis: ']
rez = []
for i in a:
    if type(i)== int:
        rez += i
print(rez)
