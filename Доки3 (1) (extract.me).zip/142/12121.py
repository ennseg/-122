a='abwgdevzijklmnoprtufhcqx'
abc=list(a)
print(abc)
b='.- -... .-- --. -.. . ...- --.. .. .--- -.- .-.. -- -. --- .--. .-. ... - ..- ..-. .... -.-. --.- -..- '
abcm=b.split( )
indm=''
print(abcm)
text=input("Ведите текст для перевода на английском ")
for i in range(len(text)):
    ind=abc.index(text[i])
    indm=indm+abcm[ind]+' '
print(f'Строка в азбуке морзе выглядит так {indm}')
