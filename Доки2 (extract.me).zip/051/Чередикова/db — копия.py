import sqlite3 as sql

con = sql.connect('test.db')
with con:
    con.execute("""
        CREATE TABLE HUMAN (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            age INTEGER
        );
    """)
    sql = 'INSERT INTO USER (id, name, age) values(?, ?, ?)'
data = [
    (1, 'Nastya', 17 ),
    (2, 'Caroline', 19),
    (3, 'Jace', 20)
]
with con:
    con.executemany(sql, data)
    
with con:
    data = con.execute("SELECT * FROM USER WHERE age <= 22")
    for row in data:
        print(row)
