M=0
alp="ABCDEFGHIJKLMOPQRSTUVWXYZ"
with open("24-164.txt","r") as F:
    for line in F:
        kG=0
        for i in range(len(line)):
            if line[i]=="G":
                kG+=1
        if kG<15:
            for el in alp:
                mas= []
                for i in range(len(line)):
                    if el==line[i]:
                        mas.append(i)
                M=max(M,mas[-1]-mas[0])
print(M)
