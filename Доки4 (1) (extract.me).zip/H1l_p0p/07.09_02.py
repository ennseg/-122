import random as rn
abc = [chr(i) for i in range(ord("A"), ord("Z")+1)] + [chr(i) for i in range(ord("a"), ord("z")+1)]

def AllCaps(func):
    def _wrapper():
        print(func().upper())
    return _wrapper

@AllCaps
def randprint(ln=1000, alpha=abc):
    s = ''
    for i in range(ln):
        s+=rn.choice(alpha)
    return s

randprint()        
        
