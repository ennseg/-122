"""
a=[26 ,888, 16, 66,321]
k=0
for i in a:
    if len(set(str(i)))==1:
        k+=1
print(k)
"""

#1
def inany(x,n):
    a='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    res=''
    while(x>0):
        res=a[x%n]+res
        x=x//n
    return res
'''
a=7**103+20*7**204-3*7**57+97

print(inany(a,7).count('6'))
'''
#2
'''
a=5*216**1256-5*36**1146+4*6**1053-1087
su=0
for i in inany(a,6):
    su+=int(i)
print(su)
'''
#3
'''
a=49**129+7**131-2
ma=0
ch=inany(a,7)
ma+=ch.count('6')
ma+=ch.count('0')
print(ma)
'''
#4
def inany(x,n):
    a='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    res=''
    while(x>0):
        res=a[x%n]+res
        x=x//n
    return res

'''
a=13*625**1320+12*125**1230-14*25**1140-13*5**1050-2500
print(inany(a,25).count('0'))
'''
#5
'''
k=0

for f in ['Е','Э']:
    for s in ['Е','Э','Г']:
        for h in ['Е','Э','Г']:
            for p in ['Е','Э','Г']:
                for y in ['Е','Э','Г']:
                    k+=1
print(k)
'''
#6
'''
k=0
for f in ['A','C','G','T']:
    for s in ['A','C','G','T']:
        for h in ['A','C','G','T']:
            for pd in ['A','C','G','T']:
                for y in ['A','C','G','T']:
                    j=f+s+h+p+y
                    if j.count('A')==2:
                        k+=1
print(k)
'''


#7
'''
for f in ['A','B','C','D']:
    for s in ['A','B','C','D']:
        for t in ['A','B','C','D']:
            j=f+s+t
            if j.find('A')-j.find('D')==1 or j.find('A')-j.find('D')==-1
'''

#5 adekvat
import itertools as it

#product -все возможные варианты
#permutations- перестановки
'''
k=0
for x in it.product('ЕГЭ',repeat=5):
    s=''.join(x)
    if(s[0] in 'ЕЭ'):
       k+=1
print(k)
'''
#6 adekvat
'''
k=0
for x in it.product('ACGT',repeat=5):
    s=''.join(x)
    if s.count('A')==2:
        k+=1
print(k)
'''
#7
k=0
for x in it.product('ABCD',repeat=3):
    s=''.join(x)
    if 'BC' not in s and 'CB' not in s and 'AA' not in s:
        if 'A' in s and(('DA' in s)or('AD' in s)) in s:
            print(s)
            k+=1
print(k)
 













