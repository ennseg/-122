result=0
with open("27-37b.txt","r") as F:
    N= int(F.readline())
    numbers=[0]*10001
    for line in F:
        x = int(line)
        a=1
        while (a<=x-a):
            if (a<x-a):result+=numbers[a]*numbers[x-a]
            else: result+=numbers[a]*(numbers[a]-1)//2
            a+=1
        numbers[x]+=1
print(result)    