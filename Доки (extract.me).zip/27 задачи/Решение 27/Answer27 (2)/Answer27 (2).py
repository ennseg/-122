#2710
o_ch,o_nch,kol,nc,ch=0,0,0,0,0
with open("27-35b.txt","r") as F:
    N=F.readline()
    for line in F:
        if int(line)!=0:
            if int(line)%2==0:
                ch+=1
                kol+=o_ch
            else:
                nc+=1
                kol+=o_nch
        else:
            o_ch+=ch
            ch=0
            o_nch+=nc
            nc=0
print(kol)