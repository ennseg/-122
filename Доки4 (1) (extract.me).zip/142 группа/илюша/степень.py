x=int(input("Введи основание >>> "))
y=int(input("Введи показатель степени >>> "))
Itogo=int()
Itogo = x**y
print(f"число x в степени y равно {Itogo}" ) 
