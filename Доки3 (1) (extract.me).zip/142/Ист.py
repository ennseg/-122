#x= int(input('введите x'))
#y= int(input('введите y'))
#Itogo = int(1)
#Itogo = x**y
#for i in range(y):
    #Itogo = Itogo*x
    #print (Itogo)
#print (F"x в степени y {Itogo}")



a = [input()for i in range(int(input()))]
f = int(input("Введите систему счисления"))
#x = 231745
#a = list(str(x))
#a.reverse()
print(a)
it = 1
st=5
for i in range(6):
    it = it + int(a[i])*f**st
    st = st - 1
    #print(it)
print(it)
    
    
    

