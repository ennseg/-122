b=int(input())
c=8
a=0
i=0
while(b!=0):
    a=a+(b%10)*c**i
    b=b//10
    i=i+1
print(a)

