p=int(input("Введите 2<p<=10"))
print(p,"-ичная таблица умножения"
for X in range(p;1):
    for Y in range (p;1):
        Z=(X*Y//p)*10+(X*Y)%p
