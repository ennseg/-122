result_min = [0]*10
result_max = [0]*10
with open("27-47b.txt","r") as F:
    N= F.readline()
    for line in F:
        mas = [int(x) for x in line.split()]
        c_sum_min = [1000000000]*10
        c_sum_max = [0]*10
        for el in result_min:
            for n in mas:
                s = el+n
                c_sum_min[s%10]=min(c_sum_min[s%10],s)
        for el in result_max:
            for n in mas:
                s = el+n
                c_sum_max[s%10]=max(c_sum_max[s%10],s)
        result_min=c_sum_min[::]
        result_max=c_sum_max[::]
print(result_min[max(result_max)%10])