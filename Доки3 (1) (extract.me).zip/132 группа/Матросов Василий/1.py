a=int(input("Введите число"))
c=int(input("Введите степень числа"))
print(a**c)
